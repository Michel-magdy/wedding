import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'

// ─── CONFIG — same values as app.js ──────────────────────────
const SUPABASE_URL  = 'YOUR_SUPABASE_URL'
const SUPABASE_ANON = 'YOUR_SUPABASE_ANON_KEY'
// ─────────────────────────────────────────────────────────────

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON)

// ─── Elements ────────────────────────────────────────────────
const loginScreen  = document.getElementById('login-screen')
const dashboard    = document.getElementById('dashboard')
const loginFormWrap = document.getElementById('login-form-wrap')
const loginSent    = document.getElementById('login-sent')
const magicBtn     = document.getElementById('magic-link-btn')
const emailInput   = document.getElementById('admin-email')
const loginError   = document.getElementById('login-error')
const logoutBtn    = document.getElementById('logout-btn')
const tbody        = document.getElementById('rsvp-tbody')
const dashDate     = document.getElementById('dash-date')

let allRsvps = []
let currentFilter = 'all'

// ─── On load — check if already logged in ────────────────────
const { data: { session } } = await supabase.auth.getSession()
if (session) {
  showDashboard()
} else {
  loginScreen.hidden = false
}

// ─── Magic link ───────────────────────────────────────────────
magicBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim()
  if (!email) { emailInput.focus(); return }

  magicBtn.disabled = true
  magicBtn.textContent = 'Sending…'

  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { emailRedirectTo: window.location.href }
  })

  if (error) {
    loginError.textContent = error.message
    loginError.hidden = false
    magicBtn.disabled = false
    magicBtn.textContent = 'Send magic link'
  } else {
    loginFormWrap.hidden = true
    loginSent.hidden = false
  }
})

// ─── Handle magic link redirect (token in URL) ────────────────
supabase.auth.onAuthStateChange((_event, session) => {
  if (session) showDashboard()
})

// ─── Logout ───────────────────────────────────────────────────
logoutBtn.addEventListener('click', async () => {
  await supabase.auth.signOut()
  location.reload()
})

// ─── Show dashboard ───────────────────────────────────────────
async function showDashboard () {
  loginScreen.hidden = true
  dashboard.hidden   = false
  dashDate.textContent = `Last refreshed: ${new Date().toLocaleString()}`
  await loadRsvps()
  subscribeRealtime()
}

// ─── Load RSVPs ───────────────────────────────────────────────
async function loadRsvps () {
  const { data, error } = await supabase
    .from('rsvps')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    tbody.innerHTML = `<tr><td colspan="5" class="table-loading">Error loading data.</td></tr>`
    return
  }

  allRsvps = data
  renderTable()
  renderStats()
}

// ─── Real-time subscription ───────────────────────────────────
function subscribeRealtime () {
  supabase
    .channel('rsvps-realtime')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'rsvps' }, () => {
      loadRsvps()
      dashDate.textContent = `Last updated: ${new Date().toLocaleString()}`
    })
    .subscribe()
}

// ─── Stats ────────────────────────────────────────────────────
function renderStats () {
  const total   = allRsvps.length
  const yes     = allRsvps.filter(r => r.is_coming).length
  const no      = total - yes
  const comment = allRsvps.filter(r => r.comment).length

  document.getElementById('stat-total').textContent   = total
  document.getElementById('stat-yes').textContent     = yes
  document.getElementById('stat-no').textContent      = no
  document.getElementById('stat-comment').textContent = comment
}

// ─── Table ────────────────────────────────────────────────────
function renderTable () {
  const filtered = allRsvps.filter(r => {
    if (currentFilter === 'yes')     return r.is_coming
    if (currentFilter === 'no')      return !r.is_coming
    if (currentFilter === 'comment') return !!r.comment
    return true
  })

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="table-loading">No results.</td></tr>`
    return
  }

  tbody.innerHTML = filtered.map((r, i) => `
    <tr>
      <td class="row-num">${i + 1}</td>
      <td><strong style="font-weight:400">${esc(r.name)}</strong></td>
      <td>
        <span class="badge ${r.is_coming ? 'badge-yes' : 'badge-no'}">
          ${r.is_coming ? '✓ Attending' : '✗ Not attending'}
        </span>
      </td>
      <td>
        ${r.comment
          ? `<span class="note-text">${esc(r.comment)}</span>`
          : `<span class="no-note">—</span>`}
      </td>
      <td class="date-cell">${formatDate(r.created_at)}</td>
    </tr>
  `).join('')
}

// ─── Filter buttons ───────────────────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'))
    btn.classList.add('active')
    currentFilter = btn.dataset.filter
    renderTable()
  })
})

// ─── Helpers ─────────────────────────────────────────────────
function esc (str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
}
function formatDate (iso) {
  return new Date(iso).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  })
}
