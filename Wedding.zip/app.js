import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'

// ─── CONFIG — replace these two values ───────────────────────
const SUPABASE_URL  = 'YOUR_SUPABASE_URL'
const SUPABASE_ANON = 'YOUR_SUPABASE_ANON_KEY'
// ─────────────────────────────────────────────────────────────

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON)

const form       = document.getElementById('rsvp-form')
const submitBtn  = document.getElementById('submit-btn')
const btnText    = submitBtn.querySelector('.btn-text')
const btnLoading = submitBtn.querySelector('.btn-loading')
const thankyou   = document.getElementById('thankyou')
const thankyouName = document.getElementById('thankyou-name')

form.addEventListener('submit', async (e) => {
  e.preventDefault()

  const name    = form.name.value.trim()
  const coming  = form.coming.value          // 'yes' or 'no'
  const comment = form.comment.value.trim() || null

  // Basic validation
  if (!name) return shake(form.name)
  if (!coming) return shake(document.querySelector('.radio-group'))

  // Loading state
  submitBtn.disabled = true
  btnText.hidden     = true
  btnLoading.hidden  = false

  const { error } = await supabase
    .from('rsvps')
    .insert({ name, is_coming: coming === 'yes', comment })

  if (error) {
    console.error(error)
    submitBtn.disabled = false
    btnText.hidden     = false
    btnLoading.hidden  = true
    alert('Something went wrong. Please try again.')
    return
  }

  // Show thank you
  form.hidden          = true
  thankyouName.textContent = name.split(' ')[0]
  thankyou.hidden      = false
})

function shake (el) {
  el.style.animation = 'none'
  el.getBoundingClientRect()
  el.style.animation = 'shake 0.4s ease'
  el.addEventListener('animationend', () => el.style.animation = '', { once: true })
}

// Inject shake keyframes
const style = document.createElement('style')
style.textContent = `
  @keyframes shake {
    0%,100% { transform: translateX(0); }
    20%      { transform: translateX(-6px); }
    40%      { transform: translateX(6px); }
    60%      { transform: translateX(-4px); }
    80%      { transform: translateX(4px); }
  }
`
document.head.appendChild(style)
